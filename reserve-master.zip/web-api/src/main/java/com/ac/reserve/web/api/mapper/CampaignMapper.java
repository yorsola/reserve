package com.ac.reserve.web.api.mapper;

import com.ac.reserve.web.api.po.Campaign;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;


@Mapper
public interface CampaignMapper extends BaseMapper<Campaign> {
}