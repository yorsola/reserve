package com.ac.reserve.web.api.dto;


import com.ac.reserve.web.api.po.Round;
import lombok.Data;

@Data
public class RoundDTO extends Round {
}
