package com.ac.reserve.web.api.mapper;

import com.ac.reserve.web.api.po.Round;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;


@Mapper
public interface RoundMapper extends BaseMapper<Round> {
}