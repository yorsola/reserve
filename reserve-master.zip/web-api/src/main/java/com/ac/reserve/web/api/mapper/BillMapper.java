package com.ac.reserve.web.api.mapper;

import com.ac.reserve.web.api.po.Bill;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;


@Mapper
public interface BillMapper extends BaseMapper<Bill> {
}