package com.ac.reserve.web.api.service;

import com.ac.reserve.web.api.po.User;
import com.baomidou.mybatisplus.extension.service.IService;


public interface UserService extends IService<User> {

}
