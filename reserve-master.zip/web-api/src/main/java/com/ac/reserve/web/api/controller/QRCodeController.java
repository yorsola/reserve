package com.ac.reserve.web.api.controller;

public class QRCodeController {
}
