package com.ac.reserve.web.api.service;

import com.ac.reserve.web.api.po.Bill;
import com.baomidou.mybatisplus.extension.service.IService;


public interface BillService extends IService<Bill> {

}
