package com.ac.reserve.common.constant;

public class ResponseConstant {

}
