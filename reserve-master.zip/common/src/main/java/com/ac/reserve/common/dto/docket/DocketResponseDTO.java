package com.ac.reserve.common.dto.docket;

import lombok.Data;

@Data
public class DocketResponseDTO {
    private String code;
    private String msg;
    private String data;
}
