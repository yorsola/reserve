package com.ac.reserve.common.config.callback;

import org.quartz.CronScheduleBuilder;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.SmartLifecycle;
import org.springframework.stereotype.Component;


@Component
public class CommonLifecycle implements SmartLifecycle {

//    @Autowired
//    private Scheduler scheduler;
//
//    @Autowired
//    private PendingCheckJob pendingCheckJob;
//
//    @Autowired
//    private ErrorEnrollHistoryCheckJob errorEnrollHistoryCheckJob;
//
//    @Autowired
//    private ErrorGeneralHistoryCheckJob errorGeneralHistoryCheckJob;
//
//    @Value("${rewards.report.send.enable}")
//    private boolean enableSendReport;
//
//    private boolean isRunning = false;
//
//    private CommonJobCallBack mPointsCheckJobCompleteCallBack = new CommonJobCallBack() {
//
//        @Override
//        public void loadDataComplete(CommonResponseModel commonResponseModel) {
//            try {
//            } catch (ServiceException e) {
//                Log.e(e);
//            }
//            Log.i("loadDataComplete = " + commonResponseModel.message);
//        }
//    };
//
//    @Override
//    public boolean isRunning() {
//        return isRunning;
//    }
//
//    @Override
//    public void start() {
//        isRunning = true;
//        pendingCheckJob.setCallBack(mPointsCheckJobCompleteCallBack);
//        boolean isSchedulePeningCheckJob = schedulePendingPointsCheckJob();
//        Log.i("Pending Point Job " + isSchedulePeningCheckJob);
//
//        // boolean isScheduleExpirationCheckJob = scheduleExpirationPointsCheckJob();
//        // Log.i("Expiration Point Job " + isScheduleExpirationCheckJob);
//        boolean isScheduleSendPartnerReportCheckJob = scheduleSendPartnerReportCheckJob();
//        Log.i("Send Partner Report Job " + isScheduleSendPartnerReportCheckJob);
//
//        errorEnrollHistoryCheckJob.setCallBack(mPointsCheckJobCompleteCallBack);
//        boolean isScheduleErrorEnrollHistoryCheckJob = scheduleErrorEnrollHistoryCheckJob();
//        Log.i("Error Enroll History Job " + isScheduleErrorEnrollHistoryCheckJob);
//
//        errorGeneralHistoryCheckJob.setCallBack(mPointsCheckJobCompleteCallBack);
//        boolean isScheduleErrorGeneralHistoryCheckJob = scheduleErrorGeneralHistoryCheckJob();
//        Log.i("Error General History Job " + isScheduleErrorGeneralHistoryCheckJob);
//    }
//
//    @Override
//    public void stop() {
//        isRunning = false;
//    }
//
//    @Override
//    public int getPhase() {
//        return 1223;
//    }
//
//    @Override
//    public boolean isAutoStartup() {
//        return true;
//    }
//
//    @Override
//    public void stop(Runnable callback) {
//        callback.run();
//        isRunning = false;
//    }
//
//    private boolean schedulePendingPointsCheckJob() {
//        JobDataMap jobDataMap = new JobDataMap();
//        jobDataMap.put("job", "pending");
//        // Daily Job , for track pending points
//        JobDetail job = CronTaskFactory.getJobDetail(PendingCheckJob.class, null, null, jobDataMap);
//        CronScheduleBuilder builder = CronScheduleBuilder.cronSchedule("0 0 2 * * ?");
//        // SimpleScheduleBuilder builder =
//        // SimpleScheduleBuilder.simpleSchedule().withIntervalInSeconds(5)
//        // .withRepeatCount(1);
//        Trigger trigger = CronTaskFactory.getJobTriggerBuilder(PendingCheckJob.class.getSimpleName(), null).startNow()
//                .withSchedule(builder).build();
//        try {
//            scheduler.scheduleJob(job, trigger);
//            return true;
//        } catch (SchedulerException e) {
//            Log.e(e);
//            return false;
//        }
//    }
//
//    private boolean scheduleExpirationPointsCheckJob() {
//        JobDataMap jobDataMap = new JobDataMap();
//        jobDataMap.put("job", "expiration");
//        // Monthly Job , for track expired points
//        JobDetail expiredJob = CronTaskFactory.getJobDetail(ExpirationCheckJob.class, null, null, jobDataMap);
//        CronScheduleBuilder builder = CronScheduleBuilder.cronSchedule("0 30 1 1 * ?");
//        // SimpleScheduleBuilder builder =
//        // SimpleScheduleBuilder.simpleSchedule().withIntervalInSeconds(5)
//        // .withRepeatCount(1);
//        Trigger expiredTrigger = CronTaskFactory.getJobTriggerBuilder(ExpirationCheckJob.class.getSimpleName(), null)
//                .startNow().withSchedule(builder).build();
//
//        try {
//            scheduler.scheduleJob(expiredJob, expiredTrigger);
//            return true;
//        } catch (SchedulerException e) {
//            Log.e(e);
//            return false;
//        }
//    }
//
//    private boolean scheduleSendPartnerReportCheckJob() {
//        if(enableSendReport) {
//            JobDataMap jobDataMap = new JobDataMap();
//            jobDataMap.put("job", "send report");
//            // Monthly Job , for track expired points
//            JobDetail expiredJob = CronTaskFactory.getJobDetail(SendReportJob.class, null, null, jobDataMap);
//            CronScheduleBuilder builder = CronScheduleBuilder.cronSchedule("0 0 6 * * ?"); //"0 0 6 * * ?"
//            // SimpleScheduleBuilder builder =
//            // SimpleScheduleBuilder.simpleSchedule().withIntervalInSeconds(5)
//            // .withRepeatCount(0);
//            Trigger expiredTrigger = CronTaskFactory.getJobTriggerBuilder(SendReportJob.class.getSimpleName(), null)
//                    .startNow().withSchedule(builder).build();
//
//            try {
//                scheduler.scheduleJob(expiredJob, expiredTrigger);
//                return true;
//            } catch (SchedulerException e) {
//                Log.e(e);
//                return false;
//            }
//        }else {
//            Log.i("Send campaign statistics report job is disabled. enabledSendReport:" + enableSendReport);
//            return false;
//        }
//
//    }
//
//    /**
//     * resolve error enroll history
//     * @return
//     */
//    private boolean scheduleErrorEnrollHistoryCheckJob() {
//        JobDataMap jobDataMap = new JobDataMap();
//        jobDataMap.put("job", "error enroll history");
//        // daily Job , for resolve error enroll history
//        JobDetail errorJob = CronTaskFactory.getJobDetail(ErrorEnrollHistoryCheckJob.class, null, null, jobDataMap);
//        CronScheduleBuilder builder = CronScheduleBuilder.cronSchedule("0 0 3 * * ?");
//        Trigger expiredTrigger = CronTaskFactory.getJobTriggerBuilder(ErrorEnrollHistoryCheckJob.class.getSimpleName(), null)
//                .startNow().withSchedule(builder).build();
//        try {
//            scheduler.scheduleJob(errorJob, expiredTrigger);
//            return true;
//        } catch (SchedulerException e) {
//            Log.e(e);
//            return false;
//        }
//    }
//
//    /**
//     * resolve error general history
//     * @return
//     */
//    private boolean scheduleErrorGeneralHistoryCheckJob(){
//        JobDataMap jobDataMap = new JobDataMap();
//        jobDataMap.put("job", "error general history");
//        // daily Job , for resolve error enroll history
//        JobDetail errorJob = CronTaskFactory.getJobDetail(ErrorGeneralHistoryCheckJob.class, null, null, jobDataMap);
//        CronScheduleBuilder builder = CronScheduleBuilder.cronSchedule("0 0 4 * * ?");
//        Trigger expiredTrigger = CronTaskFactory.getJobTriggerBuilder(ErrorGeneralHistoryCheckJob.class.getSimpleName(), null)
//                .startNow().withSchedule(builder).build();
//        try {
//            scheduler.scheduleJob(errorJob, expiredTrigger);
//            return true;
//        } catch (SchedulerException e) {
//            Log.e(e);
//            return false;
//        }
//    }
}
