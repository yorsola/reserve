
package com.ac.reserve.common.config.callback;


import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import java.util.Date;
import java.util.List;


@Configuration
public class CheckJob implements Job {
//
//    /*
//     * (non-Javadoc)
//     *
//     * @see org.quartz.Job#execute(org.quartz.JobExecutionContext)
//     */
//
//    @Autowired
//    RewardsTransactionDBService rewardsTransactionDBService;
//
//    @Autowired
//    TransactionService transactionService;
//
//    @Autowired
//    RewardsUserInfoService rewardsUserInfoService;
//
//    private static CommonJobCallBack mPendingPointsCheckJobCallBack = null;
//
//    @Override
//    public void execute(JobExecutionContext context) throws JobExecutionException {
//        Log.i("It's a Pending Check Job");
//        startPendingPointsCheckThread();
//    }
//
//    private void startPendingPointsCheckThread() {
//        new Thread() {
//
//            @Override
//            public void run() {
//                super.run();
//                //1.query the transaction in 7 days
//                //current day start - 7   to  current day end
//                Date now = new Date();
//                Date start = DateUtil.addDays(DateUtil.getDayStart(now), -7);
//                Date end = DateUtil.getDayEnd(now);
//
//                List<TransactionHistory> histories = rewardsTransactionDBService.getPendingTransactionHistories(start, end);
//                Log.i(getClass(), "Handle pending transactions amount: " + (histories==null?0:histories.size()));
//
//                //2.effect the transactions
//                if (histories != null)
//                    for (TransactionHistory history : histories) {
//                        try {
//                            transactionService.pendingTransactionEventHandle(history);
//                        } catch (Exception e) {
//                            Log.e(getClass(),
//                                    "Effect pending transaction[" + history.getTrackingno() + "] fail: " + e.getMessage());
//                        }
//                    }
//
//                //3.make response and callback
//                if (mPendingPointsCheckJobCallBack != null) {
//                    CommonResponseModel commonResponseModel = new CommonResponseModel();
//                    commonResponseModel.result = 1;
//                    commonResponseModel.message = "complete";
//                    mPendingPointsCheckJobCallBack.loadDataComplete(commonResponseModel);
//                }
//            }
//        }.start();
//    }
//
//    public void setCallBack(CommonJobCallBack callBack) {
//        if (callBack != null) {
//            Log.i(callBack + " not null");
//        } else {
//            Log.i(callBack + " is null");
//        }
//        mPendingPointsCheckJobCallBack = callBack;
//    }
}
