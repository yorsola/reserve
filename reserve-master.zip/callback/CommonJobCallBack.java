package com.ac.reserve.common.config.callback;


public interface CommonJobCallBack {
//    public void loadDataComplete(CommonResponseModel commonResponseModel);
}
